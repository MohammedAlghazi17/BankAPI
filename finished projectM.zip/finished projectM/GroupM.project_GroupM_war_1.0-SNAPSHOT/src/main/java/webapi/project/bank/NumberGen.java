package webapi.project.bank;

import java.util.Random;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/

public class NumberGen {
    Random r = new Random();
    public NumberGen() {
        
    }
    public int randomInt(int num){
        String str = "";
        for(int i =0; i<num; i++){
            str+=r.nextInt(9);
        }
        return Integer.parseInt(str);
    }
    
        public long randomLong(int num){
        String str = "";
        for(int i =0; i<num; i++){
            str+=r.nextInt(9);
        }
        return Long.parseLong(str);
    }
    
    
}
