package webapi.project;

import java.util.ArrayList;
import java.util.List;
import webapi.project.bank.Account;
import webapi.project.bank.Customer;
import webapi.project.database.Database;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/

public class CustomerService {
    Database db = new Database();
    private List<Customer> list = db.getCustomerDB();
    private AccountService accountService = new AccountService();
    
    
    public Customer createCustomer(Customer c){
        c.setC_id(list.size()+1);
        
        Account a = accountService.createAccount();
        List<Account> accounts = new ArrayList<>();
        accounts.add(a);
        c.setAccounts(accounts);
        list.add(c);        
       return c;
    }
    
    public  Customer getCustomer(String email){
        for(int i =0; i<list.size(); i++){
            if(list.get(i).getEmail().equalsIgnoreCase(email)){
                return list.get(i);
            }
        }
        return null;
    }
    
    public List<Customer> getCustomers(){
        return list;
    }

    public Customer getCustomerByEmail(String email) {
         for(int i =0; i<list.size(); i++){
            if(list.get(i).getEmail().equals(email)){
                return list.get(i);
            }
        }
        return null;
    }
    
   
   
}
