package webapi.project.resource;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import webapi.project.AccountService;
import webapi.project.bank.Account;
import webapi.project.bank.Customer;
import webapi.project.database.Database;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/

@Path("/accounts")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AccountResource {
    AccountService as = new AccountService();
    Database db = new Database();
    public List<Account> list = db.getAccountDB();
    
    @GET
    public List<Account> getAllAccounts(){
        return as.getAccounts();
    }
    
    @GET
    @Path("/{accountNo}")
    public Account getAccount(@PathParam("accountNo") long accountNo){
        System.out.println("accountni1979");
        return as.getAccount(accountNo);
        
    } 
    
    
    @GET
    @Path("/{accountNo}/balance")
    public String getBalance(@PathParam("accountNo") long accountNo) {
        return as.getBalance(accountNo);
        }
    
    @POST
    @Path("addnewaccount")
    public Account addAccount(Customer c){
        return as.addNewAccount(c);
    }
    
    @Path("/{accountNo}/transactions")
    public TransactionResource getTransactionResource(){
        return new TransactionResource();
    }    
    
}
