
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webapi.project.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import webapi.project.TransactionService;
import webapi.project.bank.Account;

import webapi.project.bank.Transaction;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/

@Path("/transactions")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class TransactionResource {
    
    TransactionService ts = new TransactionService();   
    
    /*@GET
    public List<Transaction> getTransactions(@PathParam("email") String email, @PathParam("accountNo") long accountNo){
        return ts.getTransactions(email, accountNo);
    }*/
    
    @GET
    public List<Transaction> getTransactions(){
        return ts.getTransactions();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/lodgement")
    public Transaction createLodgement(Account a){
        double amount = a.getBalance();
        long creditCardNo = a.getCreditCardNo();
        return ts.createLodgement(amount, creditCardNo);
    }
    @POST
    @Path("/withdrawal")
    public Transaction createWithdrawal(Account a){
        double amount = a.getBalance();
        long creditCardNo = a.getCreditCardNo();
        return ts.createWithdrawal(amount, creditCardNo);
    }
    
    @POST
    @Path("/transfer")
    public List<Transaction> createTransfer(List<Account> al){
        double amount = al.get(0).getBalance();
        long accountNoFrom = al.get(1).getAccountNo();
        long accountNoTo = al.get(0).getAccountNo();
        return ts.createTransfer(amount, accountNoTo,accountNoFrom);
    }    
    
   /*  @POST
    @Path("/transfer")
    public List<Transaction> createTransfer(double amount, long accountNoTo,long accountNoFrom){
        return ts.createTransfer(amount, accountNoTo,accountNoFrom);
    }*/    
}
