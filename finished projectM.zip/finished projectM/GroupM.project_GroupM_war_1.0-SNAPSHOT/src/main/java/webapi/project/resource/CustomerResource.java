package webapi.project.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import webapi.project.CustomerService;
import webapi.project.bank.Customer;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/
@Path("/customers")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CustomerResource {
    

    CustomerService customerService = new CustomerService();
        
        //Get method returning all customers of bank, suitable for bank staff to use or for debugging
        //e.g. 0.0.0:8080/api/customers
        @GET
        public List<Customer> getAllCustomers(){
            return customerService.getCustomers();
        }
        
        //POST request to create a new banking customer
        //e.g localhost:49000/api/customers/create
        @POST
        @Path("/create")
        public Customer createCustomer(Customer customer){
            return customerService.createCustomer(customer);
        }
 
        //GET method to retrieve customer by email
        //e.g localhost:49000/api/customers/getByEmail/Shane.Ryan@student.ncirl.ie
        @GET
        @Path("/getByEmail/{email}")
        public Customer getCustomerByEmail(@PathParam("email") String email){
            return customerService.getCustomerByEmail(email);
        }
   
          //path linking accounts subresource
        //e.g localhost:49000/api/customers/1/accounts
        @Path("/{customerId}/accounts")
        public AccountResource getAccountsResource() {
        System.out.println("getting Accounts Resource");
        return new AccountResource();
        }
    
}