package webapi.project;

import java.util.ArrayList;
import java.util.List;
import webapi.project.bank.Account;
import webapi.project.bank.Customer;
import webapi.project.bank.NumberGen;
import webapi.project.bank.Transaction;
import webapi.project.database.Database;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/

public class AccountService {
    Database db = new Database();
    private List<Account> list = db.getAccountDB();
    private List<Customer> c_list = db.getCustomerDB();
    NumberGen gen = new NumberGen();
    
    
    public Account createAccount(){
        List <Transaction> t = new ArrayList<>();
        Account a = new Account(1979, gen.randomInt(4), 100.0,gen.randomLong(9),t);
        list.add(a);
        return a;
    }
    
    public Account addNewAccount(Customer cs){
        Account a = this.createAccount();
        for(int i=0;i <c_list.size(); i++){
            Customer c = (Customer) c_list.get(i);
            if(c.getEmail()== cs.getEmail()){
                List<Account> c_account = c.getAccounts();
                c_account.add(a);
                c.setAccounts(c_account);
                c_list.set(i, c);
            }
        }
        return a;
    }
    
    public String getBalance(long accountNo){
        for(int i=0;i <list.size(); i++){
           Account a = (Account) list.get(i);
            if(a.getAccountNo()== accountNo){
               return "Your balance is: "+ a.getBalance();
            }
        }
        return "Account not found";
    }
    
    public Account getAccount(long accountNo){
        for(int i =0; i<list.size(); i++){
            if(list.get(i).getAccountNo()==(accountNo)){
                return list.get(i);
            }
        }
        return null;       
    }//end Accont getAccount
    
    public List<Account> getAccounts(){
        return list;
    }
    
    public List<Account> getAccounts(String email){
        CustomerService cs = new CustomerService();
        Customer c = cs.getCustomer(email);
        return c.getAccounts();
        
    }
        
    
}
