package webapi.project.bank;

import java.util.List;

/*
 *  BSHC4 - Data Analytics, Web Services & API Development CA2 - Group Project
 *  Student Names: Mohammed Alghazi, Lucas Villalba, Andrew Kelly, Jordan-Lee Graham
 *  Student IDs: x18208495, x19120222, x18212158 ,x19103310
*/

public class Account {
    
    private int sortCode;
    private long accountNo;
    private double balance;
    private long creditCardNo;

    public long getCreditCardNo() {
        return creditCardNo;
    }

    public void setCreditCardNo(long creditCardNo) {
        this.creditCardNo = creditCardNo;
    }
    private List<Transaction> transactions;

    public int getSortCode() {
        return sortCode;
    }

    public void setSortCode(int sortCode) {
        this.sortCode = sortCode;
    }

    public long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public Account(int sortCode, long accountNo, double balance, long creditCardNo, List<Transaction> transactions) {
        this.sortCode = sortCode;
        this.accountNo = accountNo;
        this.balance = balance;
        this.creditCardNo= creditCardNo;
        this.transactions = transactions;
    }
    

    public Account() {
    }
    
}
